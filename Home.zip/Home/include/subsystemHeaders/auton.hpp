#include "main.h"

std::shared_ptr<OdomChassisController> initOdom();

void Turn(int degrees);
