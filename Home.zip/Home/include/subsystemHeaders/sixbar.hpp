#include "main.h"



// Helper functions

void setLift(int power);

void SetLiftMotor();

void Pon();
void Poff();

void SetP();

void Wing();

void AutonWing();

int SetLiftExpo(int percentage);
