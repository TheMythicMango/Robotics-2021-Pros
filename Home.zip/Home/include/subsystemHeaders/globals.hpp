#include "main.h"

// Motors
extern pros::Motor sixbar;
extern pros::Motor sixbar2;
extern pros::Motor topRight;
extern pros::Motor topLeft;
extern pros::Motor bottomRight;
extern pros::Motor bottomLeft;
extern pros::Motor upRight;
extern pros::Motor upLeft;
extern pros::ADIDigitalOut piston;
extern pros::ADIDigitalOut rightWing;
extern pros::ADIDigitalOut leftWing;

// Odometry
extern okapi::Motor odomFrontRight;
extern okapi::Motor odomFrontLeft;
extern okapi::Motor odomBackRight;
extern okapi::Motor odomBackLeft;
extern okapi::Motor odomUpRight;
extern okapi::Motor odomUpLeft;

extern pros::Controller controller;

extern pros::IMU inertial;


std::string GetTemp(pros::Motor moter);
