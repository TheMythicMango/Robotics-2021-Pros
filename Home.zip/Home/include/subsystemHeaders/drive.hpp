#include "main.h"

// Helper functions
void setDrive(int left, int right);
void resetDriveEncoders();

// Driver control functions
void SetDriveMotors();

// Autonomous functions
void verticalTranslation(int units, int voltage);
double averageEncoderVal();

int SetDriveExpo(int percentage);

void translate(int units, int volatge);
