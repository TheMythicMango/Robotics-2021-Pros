#include "main.h"

void autonLeftGoal(){
  rightWing.set_value(false);
  piston.set_value(false);
  setDrive(10, 10);
  piston.set_value(true);
  pros::delay(300);
  setDrive(0, 0);
  pros::delay(200);
  setDrive(-80, -80);
  pros::delay(600);
  setDrive(0, 0);
}

void autonomous(){
  autonLeftGoal();
}
