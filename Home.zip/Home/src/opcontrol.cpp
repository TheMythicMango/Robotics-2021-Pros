#include "main.h"

void auton(){

  /* To find the gains
  Set all gains to zero.
  Increase the P gain until the response to a disturbance is steady oscillation.
  Increase the D gain until the the oscillations go away (i.e. it's critically damped).
  Repeat steps 2 and 3 until increasing the D gain does not stop the oscillations.
  Set P and D to the last stable values.
  Increase the I gain until it brings you to the setpoint with the number of oscillations
  desired (normally zero but a quicker response can be had if you don't mind a couple oscillations of overshoot)
  */
  rightWing.set_value(false);
  piston.set_value(false);
  // Builds Odometry
  std::shared_ptr<OdomChassisController> chassis =
  ChassisControllerBuilder().withMotors(odomFrontRight, odomFrontLeft, odomBackRight, odomBackLeft)
  .withGains
  ({0.0015, 0, 0.000} //distance 0.002
  ,{0.001, 0, 0.0001} // turn
  ,{0.000, 0, 0.0000}) //angles, helps drive straight
  .withDimensions(AbstractMotor::gearset::blue, {{3.25_in, 23.5_in}, imev5BlueTPR})
  .withOdometry().buildOdometry();
  //pros::Task my_task (chassis->getOdometry());

  //chassis->setState({0_in, 0_in, 0_deg});
  chassis->moveDistance(-7_ft);

  //chassis->turnToAngle(500_rad);
  //y_task.suspend();
  //pros::delay(800);
  rightWing.set_value(true);
}

void autonLeft(){
  rightWing.set_value(false);
  piston.set_value(false);
  setDrive(80, 80);
  pros::delay(1500);
  setDrive(10, 10);
  piston.set_value(true);
  pros::delay(100);
  setDrive(0, 0);
  pros::delay(200);
  setDrive(-80, -80);
  pros::delay(1500);
  setDrive(0, 0);
}

void autonRight(){
  rightWing.set_value(false);
  piston.set_value(false);
  setDrive(80, 81);
  pros::delay(1300);
  setDrive(10, 10);
  piston.set_value(true);
  pros::delay(100);
  setDrive(0, 0);
  pros::delay(200);
  setDrive(-80, -80);
  pros::delay(1500);
  setDrive(0, 0);
}

void driverControl(){
  rightWing.set_value(false);
  piston.set_value(false);
  while(true){
    // Drive
    SetDriveMotors();


    // Sixbar
    SetLiftMotor();

    // Pneumatics
    SetP();
    Wing();

    // Temperatures
    pros::lcd::set_text(0, "FR: " + GetTemp(topRight) + " F, "
    + "FL: " + GetTemp(topLeft) + " F, "
    + "BR: " + GetTemp(bottomRight) + " F, "
    + "BL: " + GetTemp(bottomLeft) + " F, "
    + "UR: " + GetTemp(upRight) + " F, "
    + "UL: " + GetTemp(upLeft) + " F, "
    + "SL: " +GetTemp(sixbar) + " F, "
    + "SR: " + GetTemp(sixbar2) + " F");

    pros::delay(10);
  }
}

void operatorControl() {
  driverControl();
}
