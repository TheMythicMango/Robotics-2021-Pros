#include "main.h"

// Helper functions
void setDrive(int left, int right){
  bottomLeft = left;
  topLeft = left;
  topRight = right;
  bottomRight = right;
  upRight = right;
  upLeft = left;
}

void resetDriveEncoders(){
  bottomLeft.tare_position();
  topLeft.tare_position();
  bottomRight.tare_position();
  topRight.tare_position();
}

// Driver control functions

int SetDriveExpo(int percentage){
  if(percentage >= 0)
    percentage = 1.2*pow(1.043, percentage) - 1.2 + 0.2*percentage;
  else{
    percentage = -percentage;
    percentage = 1.2*pow(1.043, percentage) - 1.2 + 0.2*percentage;
    percentage = -percentage;
  }
  return percentage;
}

void SetDriveMotors(){
  int horizontal = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_X)/1.5;
  int vertical = controller.get_analog(pros::E_CONTROLLER_ANALOG_RIGHT_Y);

  horizontal = (abs(horizontal) < 10) ? horizontal = 0: horizontal;
  vertical = (abs(vertical) < 10) ? vertical = 0: vertical;
  setDrive(SetDriveExpo(vertical) + horizontal, SetDriveExpo(vertical) - horizontal);
}

// Autonomous functions
double averageEncoderVal(){
  return (fabs(topLeft.get_position()) + fabs(bottomLeft.get_position()) + fabs(topRight.get_position()) + fabs(bottomRight.get_position()))/4;
}

int inertialDir(){

  return inertial.get_rotation();
}

void translate(int units, int voltage){
  int direction = abs(units) / units;
  // Reset motor encoders
  resetDriveEncoders();
  //inertial.tare_heading();
  // Drive forward until units are reached
  while(averageEncoderVal() < abs(units)){
    setDrive(voltage * direction + inertialDir(), voltage * direction - inertialDir());
    pros::delay(10);
  }
  // Brief Brake
  setDrive(-10 * direction, -10 * direction);
  pros::delay(50);
  // Set drive to neutral
  setDrive(0,0);
}
