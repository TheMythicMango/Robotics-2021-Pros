#include "main.h"

// Sixbar
pros::Motor sixbar(7, pros::E_MOTOR_GEARSET_36, false, pros::E_MOTOR_ENCODER_COUNTS); // Port number
pros::Motor sixbar2(8, pros::E_MOTOR_GEARSET_36, true, pros::E_MOTOR_ENCODER_COUNTS);

// Drivetrain
pros::Motor topRight(1, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor topLeft(2, pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor bottomRight(3, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor bottomLeft(4, pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor upRight(5, pros::E_MOTOR_GEARSET_06, true, pros::E_MOTOR_ENCODER_COUNTS);
pros::Motor upLeft(6, pros::E_MOTOR_GEARSET_06, false, pros::E_MOTOR_ENCODER_COUNTS);

// Odometry Motors
okapi::Motor odomFrontRight(1, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);
okapi::Motor odomFrontLeft(2, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);
okapi::Motor odomBackRight(3, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);
okapi::Motor odomBackLeft(4, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);
okapi::Motor odomUpRight(5, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);
okapi::Motor odomUpLeft(6, false, AbstractMotor::gearset::blue, AbstractMotor::encoderUnits::degrees);

// Pneumatics
pros::ADIDigitalOut piston('H');
pros::ADIDigitalOut rightWing('G');

// Controller
pros::Controller controller(pros::E_CONTROLLER_MASTER);

// Miscallanious
pros::IMU inertial(10);

std::string GetTemp(pros::Motor motor){
  float temp = (motor.get_temperature()*(9/5))+32;
  std::string s = std::to_string(temp);
  return s;
}
