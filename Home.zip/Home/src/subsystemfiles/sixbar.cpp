#include "main.h"

// Sixbar functions
void setLift(int power){
  sixbar = power;
  sixbar2 = power;
}


int SetLiftExpo(int percentage){
  if(percentage >= 0)
    percentage = 1.2*pow(1.043, percentage) - 1.2 + 0.2*percentage;
  else{
    percentage = -percentage;
    percentage = 1.2*pow(1.043, percentage) - 1.2 + 0.2*percentage;
    percentage = -percentage;
  }
  return percentage;
}


void SetLiftMotor(){
  int power = controller.get_analog(pros::E_CONTROLLER_ANALOG_LEFT_Y);
  setLift(SetLiftExpo(power));
}


void Pon(){
  piston.set_value(true);
}


void Poff(){
  piston.set_value(false);
}


bool on2 = false;
bool held2 = false;
void Wing(){
  if(controller.get_digital(DIGITAL_L1)) { // choose the appropriate button on the appropriate controller
      if(!held2) { // only do this swap if this is a new button press
         held2 = true; // remember that the button is held down so we have to wait for a release
         on2 = !on2; // toggle the state for the motor
         if(on2) { // if the motor should now be on, turn in on
            rightWing.set_value(true); // choose the appropriate port and speed
         }
         else { // if the motor should now be off, turn in off
            rightWing.set_value(false); // choose the appropriate port
         }
      }
   }
   else {
      held2 = false; // the button is not being held down, so the next time it is detected is a new press
   }
}


bool POn = false;
bool buttonHeld = false;
void SetP(){
    if(controller.get_digital(DIGITAL_R1)) { // choose the appropriate button on the appropriate controller
      if(!buttonHeld) { // only do this swap if this is a new button press
         buttonHeld = true; // remember that the button is held down so we have to wait for a release
         POn = !POn; // toggle the state for the motor
         if(POn) { // if the motor should now be on, turn in on
            Pon(); // choose the appropriate port and speed
         }
         else { // if the motor should now be off, turn in off
            Poff(); // choose the appropriate port
         }
      }
   }
   else {
      buttonHeld = false; // the button is not being held down, so the next time it is detected is a new press
   }
}

void AutonWing(){
  rightWing.set_value(true);
}
