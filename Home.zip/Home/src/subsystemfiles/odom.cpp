#include "main.h"

std::shared_ptr<OdomChassisController> initOdom(){
  std::shared_ptr<OdomChassisController> chassis =
  ChassisControllerBuilder().withMotors(1, -2).withGains({0.001, 0, 0.0001},{0.001, 0, 0.0001},{0.001, 0, 0.0001}).withDimensions(AbstractMotor::gearset::blue, {{3.25_in, 8.3_in}, imev5BlueTPR}).withOdometry().buildOdometry();

  return chassis;
}
