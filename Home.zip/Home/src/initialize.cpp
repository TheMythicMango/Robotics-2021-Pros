#include "main.h"

void on_center_button(){
  static bool pressed = false;
  pressed = !pressed;
  if(pressed){
    pros::lcd::set_text(2, "I was pressed!");
  } else{
    pros::lcd::clear_line(2);
  }
}

// Coast: lets the motor do what it wants to do
// Hold: trys to keep motor at that position
// Brake: same as hold, but if you forcefully move it, it will not counteract it

void initialize(){
  pros::lcd::initialize();
  pros::lcd::set_text(0, "Welcome 57249A");

  topLeft.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
  bottomLeft.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
  topRight.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
  bottomRight.set_brake_mode(pros::E_MOTOR_BRAKE_COAST);
  sixbar.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  sixbar.set_brake_mode(pros::E_MOTOR_BRAKE_HOLD);
  pros::IMU intertial(20);
  rightWing.set_value(false);
  piston.set_value(false);
  pros::delay(2000);
}

void disabled() {}
